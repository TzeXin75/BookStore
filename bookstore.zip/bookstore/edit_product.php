<?php
require_once 'db.php';

// 1. INITIALIZE VARIABLES (Prevents the warnings)
$errors = [];
$success = '';
$categories = [
    'Fiction' => ['Novel','Comic'],
    'Non-Fiction' => ['Biography','Self-help'],
    'Education' => ['Textbook'],
    'Children' => ['Color Book']
];

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 2. FETCH CURRENT DATA
$stmt = $pdo->prepare("SELECT * FROM book WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) die("Product not found.");

// Pre-fill variables with current database values
$title = $product['title'];
$description = $product['description'];
$author = $product['author'];
$publisher = $product['publisher'];
$category = $product['category'];
$subcategory = $product['subcategory'];
$language = $product['language'];
$price = $product['price'];
$stock = $product['stock'];
$coverName = $product['cover_image'];
$imagesStr = $product['images'];
$videoName = $product['video'];

// 3. PROCESS FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? $title);
    $description = trim($_POST['description'] ?? $description);
    $author = trim($_POST['author'] ?? $author);
    $publisher = trim($_POST['publisher'] ?? $publisher);
    $category = $_POST['category'] ?? $category;
    $subcategory = $_POST['subcategory'] ?? $subcategory;
    $language = $_POST['language'] ?? $language;
    $price = floatval($_POST['price'] ?? $price);
    $stock = intval($_POST['stock'] ?? $stock);

    // --- A. Handle Cover Update ---
    if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
        if (!empty($coverName) && file_exists("uploads/$coverName")) unlink("uploads/$coverName");
        $ext = pathinfo($_FILES['cover_image']['name'], PATHINFO_EXTENSION);
        $coverName = uniqid('cover_') . '.' . $ext;
        move_uploaded_file($_FILES['cover_image']['tmp_name'], "uploads/$coverName");
    }

    // --- B. Handle Gallery Update (Sequential) ---
    if (isset($_FILES['images']) && $_FILES['images']['error'][0] !== UPLOAD_ERR_NO_FILE) {
        $imageFiles = $_FILES['images'];
        if (count(array_filter($imageFiles['tmp_name'])) > 4) {
            $errors[] = "Maximum 4 gallery images allowed.";
        } else {
            $newGallery = [];
            for ($i = 0; $i < count($imageFiles['tmp_name']); $i++) {
                if ($imageFiles['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = pathinfo($imageFiles['name'][$i], PATHINFO_EXTENSION);
                    $fname = uniqid('img_') . '.' . $ext;
                    move_uploaded_file($imageFiles['tmp_name'][$i], "uploads/$fname");
                    $newGallery[] = $fname;
                }
            }
            if (!empty($newGallery)) {
                $oldImgs = explode(',', $product['images']);
                foreach($oldImgs as $o) { if(!empty($o) && file_exists("uploads/".trim($o))) unlink("uploads/".trim($o)); }
                $imagesStr = implode(',', $newGallery);
            }
        }
    }

    // --- C. Handle Video Update ---
    if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
        if (!empty($videoName) && file_exists("uploads/videos/$videoName")) unlink("uploads/videos/$videoName");
        $ext = pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
        if (in_array(strtolower($ext), ['mp4', 'webm'])) {
            $videoName = uniqid('vid_') . '.' . $ext;
            if (!is_dir('uploads/videos')) mkdir('uploads/videos', 0777, true);
            move_uploaded_file($_FILES['video']['tmp_name'], "uploads/videos/$videoName");
        } else {
            $errors[] = "Invalid video format.";
        }
    }

    // 4. EXECUTE UPDATE (All variables are now guaranteed to be defined)
    if (empty($errors)) {
        try {
            $sql = "UPDATE book SET title=?, description=?, author=?, publisher=?, category=?, subcategory=?, language=?, price=?, stock=?, cover_image=?, images=?, video=? WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$title, $description, $author, $publisher, $category, $subcategory, $language, $price, $stock, $coverName, $imagesStr, $videoName, $id]);
            $success = "✅ Product updated successfully!";
        } catch (PDOException $e) {
            $errors[] = "Update failed: " . $e->getMessage();
        }
    }
}
?>

<div class="product-page" style="margin: 0; padding: 0;">
    <h2 style="margin-bottom: 20px;">Edit Product: <?= htmlspecialchars($product['title']) ?></h2>

    <?php if ($errors): ?>
        <div class="error-box">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-box"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="product-form" style="display: flex; gap: 20px;">
        <div class="product-left">
            <div class="card">
                <h3>Basic Info</h3>
                <label>Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($product['title']) ?>" required>

                <label>Description</label>
                <textarea name="description" rows="5"><?= htmlspecialchars($product['description']) ?></textarea>
            </div>

            <div class="card">
                <h3>Author & Publisher</h3>
                <label>Author</label>
                <input type="text" name="author" value="<?= htmlspecialchars($product['author']) ?>">

                <label>Publisher</label>
                <input type="text" name="publisher" value="<?= htmlspecialchars($product['publisher']) ?>">
            </div>

            <div class="card">
                <h3>Category</h3>
                <label>Category</label>
                <select name="category" id="categorySelect" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $cat => $subs): ?>
                        <option value="<?= $cat ?>" <?= $product['category']==$cat?'selected':'' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Subcategory</label>
                <select name="subcategory" id="subcategorySelect">
                    <option value="">Select Subcategory</option>
                </select>
            </div>
        </div>

        <div class="product-right">
            <div class="card">
                <h3>Other Info</h3>
                <label>Language</label>
                <?php 
                // Define the available options
                $allowed_languages = ['English', 'Chinese', 'Malay'];
            
                $current_language = $product['language'] ?? ''; 
                ?>
                <select name="language" required>
                    <option value="">Select Language</option>
                    <?php 
                    $allowed_languages = ['English', 'Chinese', 'Malay'];
                    $current_lang = $product['language'] ?? ''; // From the database record
                    
                    foreach ($allowed_languages as $lang): ?>
                        <option value="<?= htmlspecialchars($lang) ?>" <?= ($current_lang === $lang) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($lang) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label>Price (RM)</label>
                <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($product['price']) ?>">

                <label>Stock</label>
                <input type="number" name="stock" value="<?= htmlspecialchars($product['stock']) ?>">
            </div>

        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <div class="form-group">
                <label>Main Book Cover (Limit: 1)</label>
                <input type="file" name="cover_image" id="coverInput" accept="image/*" class="form-control">
                <div id="cover-preview">
                    <?php if (!empty($product['cover_image'])): ?>
                        <div style="margin-top: 10px;">
                            <p style="font-size: 0.8rem; color: #666;">Current Cover:</p>
                            <img src="uploads/<?= $product['cover_image'] ?>" style="width: 100px; height: 140px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd;">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card">
            <h3>Product Video</h3>
            <label>Upload/Change Video (MP4/WebM)</label>
            <input type="file" name="video" accept="video/*">
            <?php if (!empty($videoName)): ?>
                <div style="margin-top:10px;">
                    <video width="200" controls><source src="uploads/videos/<?= $videoName ?>" type="video/mp4"></video>
                </div>
            <?php endif; ?>
        </div>


        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <div class="form-group">
                <label>Detail Gallery (Limit: 4)</label>
                <input type="file" name="images[]" id="imagesInput" accept="image/*" multiple class="form-control">
                <small id="gallery-error" style="color: #ef4444; display: none;">You can only select up to 4 gallery images.</small>
                
                <div id="images-preview">
                    <?php if (!empty($product['images'])): ?>
                        <div style="margin-top: 10px; display: flex; gap: 10px; flex-wrap: wrap;">
                            <?php 
                            $existing_imgs = explode(',', $product['images']);
                            foreach ($existing_imgs as $img): 
                            ?>
                                <img src="uploads/<?= trim($img) ?>" style="width: 80px; height: 80px; object-fit: cover; border-radius: 5px; border: 1px solid #ddd;">
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

            <div class="actions">
                <button type="submit" class="btn primary">Update Product</button>
            </div>
        </div>
    </form>
</div>

<script>
// --- 1. Dynamic Subcategories ---
const categories = <?= json_encode($categories) ?>;
const categorySelect = document.getElementById('categorySelect');
const subcategorySelect = document.getElementById('subcategorySelect');

function updateSubcategories(selected = null) {
    const cat = categorySelect.value;
    subcategorySelect.innerHTML = '';
    
    if (!cat || !categories[cat]) {
        subcategorySelect.disabled = true;
        subcategorySelect.innerHTML = '<option value="">Select Category First</option>';
        return;
    }
    
    subcategorySelect.disabled = false;
    categories[cat].forEach(sub => {
        const opt = document.createElement('option');
        opt.value = sub;
        opt.text = sub;
        // Pre-select the existing subcategory if we are in Edit mode
        if (selected && selected === sub) opt.selected = true;
        subcategorySelect.appendChild(opt);
    });
}

// --- 2. Cover Image Preview (Limit: 1) ---
const coverInput = document.getElementById('coverInput');
const coverPreview = document.getElementById('cover-preview');

if (coverInput) {
    coverInput.addEventListener('change', function() {
        // Clear previous new selections only (keeps the "Current Image" if it's in a different div)
        const existingNew = document.getElementById('new-cover-preview');
        if(existingNew) existingNew.remove();

        if (this.files && this.files[0]) {
            const container = document.createElement('div');
            container.id = 'new-cover-preview';
            container.style.marginTop = '10px';

            const label = document.createElement('p');
            label.innerText = 'New Cover Selection:';
            label.style.fontSize = '0.8rem';
            label.style.color = '#4f46e5';

            const img = document.createElement('img');
            img.src = URL.createObjectURL(this.files[0]);
            img.style.width = '100px';
            img.style.height = '140px';
            img.style.objectFit = 'cover';
            img.style.borderRadius = '5px';
            img.style.border = '2px solid #4f46e5';

            container.appendChild(label);
            container.appendChild(img);
            coverPreview.appendChild(container);
        }
    });
}

// --- 3. Detail Gallery Preview (Limit: 4) ---
const imagesInput = document.getElementById('imagesInput');
const imagesPreview = document.getElementById('images-preview');
const galleryError = document.getElementById('gallery-error');

if (imagesInput) {
    imagesInput.addEventListener('change', function() {
        const files = Array.from(this.files);
        
        // Enforce the 4-image limit
        if (files.length > 4) {
            galleryError.style.display = 'block';
            this.value = ""; // Reset file input
            return;
        } else {
            galleryError.style.display = 'none';
        }

        // Show previews for the new selection
        const existingNew = document.getElementById('new-gallery-container');
        if(existingNew) existingNew.remove();

        if (files.length > 0) {
            const container = document.createElement('div');
            container.id = 'new-gallery-container';
            container.style.display = 'flex';
            container.style.gap = '10px';
            container.style.marginTop = '10px';
            container.style.flexWrap = 'wrap';

            files.forEach(file => {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.style.width = '80px';
                img.style.height = '80px';
                img.style.objectFit = 'cover';
                img.style.borderRadius = '5px';
                img.style.border = '2px solid #4f46e5';
                container.appendChild(img);
            });
            imagesPreview.appendChild(container);
        }
    });
}

// --- 4. Video Preview ---
const videoInput = document.getElementById('videoInput');
const videoPreview = document.getElementById('video-preview');

if (videoInput) {
    videoInput.addEventListener('change', function() {
        if (this.files[0]) {
            const fileURL = URL.createObjectURL(this.files[0]);
            videoPreview.innerHTML = `
                <div style="margin-top:10px; background:#eef2ff; padding:10px; border: 2px solid #4f46e5; border-radius:5px;">
                    <p style="color:#4f46e5; font-weight:bold; font-size:0.8rem;">New Video Selected:</p>
                    <video width="200" controls>
                        <source src="${fileURL}" type="video/mp4">
                    </video>
                </div>`;
        }
    });
}

// Initialize subcategories with the current product's value
updateSubcategories("<?= $product['subcategory'] ?>");

// Update subcategories when main category changes
categorySelect.addEventListener('change', () => {
    updateSubcategories();
});
</script>