<?php
require_once 'db.php';
$defaultBookImage = "data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22200%22%20height%3D%22250%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Crect%20width%3D%22100%25%22%20height%3D%22100%25%22%20fill%3D%22%23f3f4f6%22%2F%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2240%25%22%20font-size%3D%2250%22%20text-anchor%3D%22middle%22%20dominant-baseline%3D%22middle%22%3E%F0%9F%93%96%3C%2Ftext%3E%3Ctext%20x%3D%2250%25%22%20y%3D%2260%25%22%20font-family%3D%22Arial%2C%20sans-serif%22%20font-size%3D%2220%22%20fill%3D%22%23555%22%20font-weight%3D%22bold%22%20text-anchor%3D%22middle%22%20dominant-baseline%3D%22middle%22%3EBookstore%3C%2Ftext%3E%3C%2Fsvg%3E";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}
$id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT * FROM book WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) die("Book not found.");

// --- GALLERY LOGIC ---
$images = !empty($book['images']) ? explode(',', $book['images']) : [];
$videoFile = !empty($book['video']) ? $book['video'] : null;

// Determine Initial Main Display
if (!empty($book['cover_image']) && file_exists("uploads/" . $book['cover_image'])) {
    $mainImage = "uploads/" . $book['cover_image'];
} else {
    $mainImage = !empty($images) ? "uploads/" . trim($images[0]) : $defaultBookImage;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($book['title']) ?></title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .book-container { display: grid; grid-template-columns: 12fr 8fr; gap: 40px; max-width: 1100px; margin: 0 auto; padding: 20px; }
        .gallery-wrapper { display: flex; gap: 15px; }
        .thumbnail-strip { display: flex; flex-direction: column; gap: 10px; }
        .thumb { width: 60px; height: 80px; object-fit: cover; cursor: pointer; border: 1px solid #ddd; opacity: 0.7; transition: 0.3s; position: relative; overflow: hidden; }
        .thumb.active, .thumb:hover { opacity: 1; border-color: #333; }
        
        /* Video thumbnail overlay */
        .video-thumb-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.3); z-index: 2; }
        
        .main-image-area { background-color: #f9f9f9; width: 100%; height: 500px; display: flex; justify-content: center; align-items: center; overflow: hidden; position: relative; border-radius: 8px; }
        .main-image-area img, .main-image-area video { max-width: 100%; max-height: 100%; object-fit: contain; }
        
        .product-info h1 { font-size: 2rem; margin-bottom: 10px; }
        .price-range { color: #5bc0de; font-size: 1.5rem; margin-bottom: 20px; font-weight: bold; }
        .specs { margin-bottom: 20px; color: #666; font-size: 0.9rem; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .description-list { padding-left: 20px; margin-bottom: 30px; line-height: 1.6; color: #555; }
        .shipping-note li { color: #d9534f; font-size: 0.9rem; margin-bottom: 8px; border-left: 2px solid #d9534f; padding-left: 10px; list-style: none; }
        .action-box { background: #f9f9f9; padding: 20px; border-top: 1px solid #eee; }
        .add-btn { background-color: #304458ff; color: white; width: 100%; padding: 15px; border: none; cursor: pointer; text-transform: uppercase; }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="book-container">
        <div class="gallery-wrapper">
            <div class="thumbnail-strip">
               <?php if ($videoFile): ?>
                    <div class="thumb video-thumb" onclick="showVideo(this)">
                        <div class="video-thumb-overlay">
                            <div class="play-triangle"></div> 
                        </div>
                        <video style="width: 100%; height: 100%; object-fit: cover;">
                            <source src="uploads/videos/<?= htmlspecialchars($videoFile) ?>#t=0.5" type="video/mp4">
                        </video>
                    </div>
                <?php endif; ?>

                <?php foreach($images as $img): ?>
                    <img src="uploads/<?= trim($img) ?>" 
                         class="thumb" 
                         onclick="showImage(this)" 
                         onerror="this.onerror=null; this.src='<?= $defaultBookImage ?>';">
                <?php endforeach; ?>
            </div>

            <div class="main-image-area" id="mainDisplayArea">
                <img id="mainImg" src="<?= $mainImage ?>" alt="<?= htmlspecialchars($book['title']) ?>" onerror="this.onerror=null; this.src='<?= $defaultBookImage ?>';">
                
                <?php if ($videoFile): ?>
                    <video id="mainVideo" controls style="display: none; width: 100%; height: 100%; background: #000;">
                        <source src="uploads/videos/<?= htmlspecialchars($videoFile) ?>" type="video/mp4">
                    </video>
                <?php endif; ?>
            </div>
        </div>

        <div class="product-info">
            <h1><?= htmlspecialchars($book['title']) ?></h1>
            <div class="price-range">RM<?= number_format($book['price'], 2) ?></div>
            <div class="specs">Author: <?= htmlspecialchars($book['author']) ?> | Publisher: <?= htmlspecialchars($book['publisher']) ?></div>
            <div class="description-list"><?= nl2br(htmlspecialchars($book['description'])) ?></div>
            <div class="shipping-note">
                <ul>
                    <li><strong>Stock:</strong> <?= $book['stock'] ?> units available.</li>
                    <li>Images are for illustration purposes only.</li>
                </ul>
            </div>
            <form action="add_to_cart.php" method="POST" class="action-box">
                <input type="number" name="quantity" value="1" min="1" max="<?= $book['stock'] ?>" style="width: 60px; margin-bottom: 10px;">
                <button type="submit" class="add-btn">Add to cart</button>
            </form>
        </div>
    </div>

    <div id="footer-placeholder"></div>

    <script>
        const mainImg = document.getElementById('mainImg');
        const mainVideo = document.getElementById('mainVideo');

        function showImage(element) {
            // Show Image, Hide Video
            mainImg.style.display = 'block';
            if(mainVideo) {
                mainVideo.style.display = 'none';
                mainVideo.pause();
            }
            
            mainImg.src = element.src;
            
            // Handle active classes
            document.querySelectorAll('.thumb').forEach(el => el.classList.remove('active'));
            element.classList.add('active');
        }

        function showVideo(element) {
            // Hide Image, Show Video
            mainImg.style.display = 'none';
            if(mainVideo) {
                mainVideo.style.display = 'block';
                mainVideo.play();
            }

            // Handle active classes
            document.querySelectorAll('.thumb').forEach(el => el.classList.remove('active'));
            element.classList.add('active');
        }

        fetch('footer.html')
        .then(r => r.text())
        .then(data => { document.getElementById('footer-placeholder').innerHTML = data; });
    </script>
</body>
</html>