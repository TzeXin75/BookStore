<?php
require_once 'db.php';

// 1. INITIALIZE ALL VARIABLES FIRST (Prevents Warnings)
$errors = [];
$success = '';
$categories = [
    'Fiction' => ['Novel','Comic'],
    'Non-Fiction' => ['Biography','Self-help'],
    'Education' => ['Textbook'],
    'Children' => ['Color Book']
];

// Form data placeholders
$title = $description = $author = $publisher = $cat_val = $sub_val = $language = $price = $stock = '';

// 2. PROCESS FORM
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $publisher = trim($_POST['publisher'] ?? '');
    $cat_val = $_POST['category'] ?? '';
    $sub_val = $_POST['subcategory'] ?? '';
    $language = $_POST['language'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $stock = intval($_POST['stock'] ?? 0);

    $coverName = '';
    $imageNames = [];

    // --- SEQUENTIAL IMAGE LOGIC ---
    
    // A. Handle Single Cover
    if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['cover_image']['name'], PATHINFO_EXTENSION);
        $coverName = uniqid('cover_') . '.' . $ext;
        if (!is_dir('uploads')) mkdir('uploads', 0777, true);
        move_uploaded_file($_FILES['cover_image']['tmp_name'], "uploads/$coverName");
    }

    // B. Handle Gallery (Keeps your selection order)
    if (isset($_FILES['images']) && !empty(array_filter($_FILES['images']['tmp_name']))) {
        $filesArr = $_FILES['images'];
        $count = count($filesArr['name']);
        
        if ($count > 4) {
            $errors[] = "Maximum 4 gallery images allowed.";
        } else {
            for ($i = 0; $i < $count; $i++) {
                if ($filesArr['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = pathinfo($filesArr['name'][$i], PATHINFO_EXTENSION);
                    $filename = uniqid('img_') . '.' . $ext;
                    if (move_uploaded_file($filesArr['tmp_name'][$i], "uploads/$filename")) {
                        $imageNames[] = $filename; // Added in sequence
                    }
                }
            }
        }
    }
    $imagesStr = implode(',', $imageNames);

    // Validation
    if (!$title) $errors[] = "Title is required.";
    if ($price <= 0) $errors[] = "Price must be greater than 0.";

    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO book (title, description, author, publisher, category, subcategory, language, price, stock, cover_image, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $author, $publisher, $cat_val, $sub_val, $language, $price, $stock, $coverName, $imagesStr]);
            $success = "✅ Product added successfully!";
            // Reset form
            $title = $description = $author = $publisher = $cat_val = $sub_val = $language = $price = $stock = '';
        } catch (PDOException $e) { $errors[] = "DB Error: " . $e->getMessage(); }
    }
}

$videoName = $product['video'] ?? ''; 

if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
    // Optional: Delete old video file if editing
    if (!empty($videoName) && file_exists("uploads/videos/$videoName")) {
        unlink("uploads/videos/$videoName");
    }

    $ext = pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
    $allowed_exts = ['mp4', 'webm', 'ogg'];
    
    if (in_array(strtolower($ext), $allowed_exts)) {
        $videoName = uniqid('vid_') . '.' . $ext;
        if (!is_dir('uploads/videos')) mkdir('uploads/videos', 0777, true);
        move_uploaded_file($_FILES['video']['tmp_name'], "uploads/videos/$videoName");
    } else {
        $errors[] = "Invalid video format. Only MP4, WebM, and OGG allowed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="style.css"> 
    <style>
        /* Extra styling for image preview matching edit page */
        .current-images {
            display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap;
        }
        .current-images img {
            width: 80px; height: 100px; object-fit: cover;
            border-radius: 5px; border: 1px solid #ddd;
        }
        .preview-label {
            font-size: 0.85rem; color: #6b7280; margin-top: 5px; display: block;
        }
    </style>
</head>
<body>



<div class="product-page">
    <h2>Add New Product</h2>

    <?php if ($errors): ?>
        <div class="error-box">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-box"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="product-form">
        <div class="product-left">
            <div class="card">
                <h3>Basic Info</h3>
                <label>Title</label>
                <input type="text" name="title" value="<?= htmlspecialchars($title) ?>" required>

                <label>Description</label>
                <textarea name="description" rows="5"><?= htmlspecialchars($description) ?></textarea>
            </div>

            <div class="card">
                <h3>Author & Publisher</h3>
                <label>Author</label>
                <input type="text" name="author" value="<?= htmlspecialchars($author) ?>">

                <label>Publisher</label>
                <input type="text" name="publisher" value="<?= htmlspecialchars($publisher) ?>">
            </div>

            <div class="card">
                <h3>Category</h3>
                <label>Category</label>
                <select name="category" id="categorySelect" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $cat => $subs): ?>
                        <option value="<?= $cat ?>" <?= $cat_val==$cat?'selected':'' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>

                <label>Subcategory</label>
                <select name="subcategory" id="subcategorySelect">
                    <option value="">Select Subcategory</option>
                </select>
            </div>
        </div>

        <div class="product-right">
            <div class="card">
                <h3>Other Info</h3>
                <label>Language</label>
                <?php $allowed_languages = ['English', 'Chinese', 'Malay'];?>
                <select name="language" required>
                    <option value="">Select Language</option>
                    
                    <?php foreach ($allowed_languages as $lang): ?>
                        <?php $selected = ($language === $lang) ? 'selected' : ''; ?>
                        
                        <option value="<?= htmlspecialchars($lang) ?>" <?= $selected ?>>
                            <?= htmlspecialchars($lang) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label>Price (RM)</label>
                <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($price) ?>">

                <label>Stock</label>
                <input type="number" name="stock" value="<?= htmlspecialchars($stock) ?>">
            </div>
        
        <div class="product-right">
             <div class="card">
            <h3>Product Video</h3>
            <label for="videoInput">Upload Video (Optional)</label>
            <input type="file" name="video" id="videoInput" accept="video/*" class="form-control">
            <?php if (!empty($product['video'])): ?>
                <p style="font-size: 0.8rem; color: #666; margin-top: 5px;">Current Video: <?= $product['video'] ?></p>
            <?php endif; ?>
        </div>
        </div>
       

<hr>



<div class="card" style="margin-bottom: 20px; padding: 20px;">
    <h3 style="margin-top: 0; margin-bottom: 15px; font-size: 1.1rem; color: #4f46e5;">
        <i ></i> Main Book Cover
    </h3>
    <div class="form-group">
        <label for="coverInput">Upload Primary Cover (Exactly 1 image)</label>
        <input type="file" name="cover_image" id="coverInput" accept="image/*" class="form-control">
        
        <div id="cover-preview" style="margin-top: 15px;">
            <?php if(!empty($book['cover_image'])): ?>
                <img src="uploads/<?= $book['cover_image'] ?>" style="width: 100px; height: 140px; object-fit: cover; border: 2px solid #e5e7eb; border-radius: 4px;">
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card" style="margin-bottom: 20px; padding: 20px;">
    <h3 style="margin-top: 0; margin-bottom: 15px; font-size: 1.1rem; color: #4f46e5;">
        <i ></i> Detail Gallery Images
    </h3>
    <div class="form-group">
        <label for="imagesInput">Upload Content Images (Maximum 4 images)</label>
        <input type="file" name="images[]" id="imagesInput" accept="image/*" multiple class="form-control">
        <p id="error-message" style="color: #ef4444; font-size: 0.85rem; display: none; margin-top: 5px;">
            <i ></i> You can only upload a maximum of 4 gallery images.
        </p>
        
        <div id="images-preview" style="margin-top: 15px; display: flex; flex-wrap: wrap; gap: 10px;">
            <?php 
            if(!empty($book['images'])) {
                $gallery = explode(',', $book['images']);
                foreach($gallery as $img) {
                    echo '<img src="uploads/'.trim($img).'" style="width: 70px; height: 70px; object-fit: cover; border: 1px solid #ddd; border-radius: 4px;">';
                }
            }
            ?>
        </div>
    </div>
</div>

            <div class="actions">
                <button type="submit" class="btn primary">Add Product</button>
            </div>
        </div>
    </form>
</div>

<script>
// --- 1. Dynamic Subcategories ---
const categories = <?= json_encode($categories) ?>;
const categorySelect = document.getElementById('categorySelect');
const subcategorySelect = document.getElementById('subcategorySelect');

function updateSubcategories(selected=null) {
    const cat = categorySelect.value;
    subcategorySelect.innerHTML = '';
    
    if (!cat || !categories[cat]) {
        subcategorySelect.disabled = true;
        subcategorySelect.innerHTML = '<option value="">Select Category First</option>';
        return;
    }
    
    subcategorySelect.disabled = false;
    categories[cat].forEach(sub => {
        const opt = document.createElement('option');
        opt.value = sub;
        opt.text = sub;
        if (selected && selected === sub) opt.selected = true;
        subcategorySelect.appendChild(opt);
    });
}

// Initialize on load (if validation failed, keep selection)
updateSubcategories("<?= $sub_val ?>");

// Update on change
categorySelect.addEventListener('change', () => {
    updateSubcategories();
});

// --- 2. Cover Image Preview  ---
const coverInput = document.getElementById('coverInput');
const coverPreview = document.getElementById('cover-preview');

if (coverInput) {
    coverInput.addEventListener('change', () => {
        coverPreview.innerHTML = ''; // clear previous preview
        const file = coverInput.files[0];
        if (file) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.width = "120px"; // Set width for better visibility
            img.style.height = "160px";
            img.style.objectFit = "cover";
            img.style.borderRadius = "4px";
            coverPreview.appendChild(img);
        }
    });
}

// --- 3. Detail Images Preview  ---
const imagesInput = document.getElementById('imagesInput');
const imagesPreview = document.getElementById('images-preview');

if (imagesInput) {
    imagesInput.addEventListener('change', () => {
        imagesPreview.innerHTML = ''; //    clear previous previews
        const files = imagesInput.files;
        
        if (files.length > 0) {
            Array.from(files).forEach(file => {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                img.style.width = "80px";
                img.style.height = "80px";
                img.style.objectFit = "cover";
                img.style.borderRadius = "4px";
                img.style.marginRight = "5px";
                imagesPreview.appendChild(img);
            });
        }
    });
}

//    initialization
updateSubcategories("<?= $sub_val ?>");
categorySelect.addEventListener('change', () => updateSubcategories());
</script>

</body>
</html>